var express = require("express");
var bp = require("body-parser");
var fs = require("fs");

var herolist = [];
var hero=[];
fs.readFile(__dirname+"/data.json", function(err, data){
    // console.log(err, JSON.parse(data));
    herolist = JSON.parse(data);
})

var app = express();
app.use('/', express.static(__dirname , { index: 'step8-handling-data-full.html' }));
app.use(bp.text());

app.get("/data", function(req, res){
    res.send(herolist);
});
app.post("/data", function(req, res){
    console.log(req.body);
    herolist.push(JSON.parse(req.body));
    res.send(herolist);
    fs.writeFileSync(__dirname+"/data.json", JSON.stringify(herolist) );
});

app.post("/data/u", function(req, res){
 herolist= JSON.parse(fs.readFileSync(__dirname+"/data.json"));
 hero.push(JSON.parse(req.body));
 console.log(JSON.parse(req.body));
 for(var i=0; i<herolist.length;i++){
     if(herolist[i].sl==hero[0].sl){
        herolist[i].title=hero[0].title;
         herolist[i].gender=hero[0].gender;
         herolist[i].firstname=hero[0].firstname;
         herolist[i].lastname=hero[0].lastname;
         herolist[i].city=hero[0].city;
         herolist[i].ticketprice=hero[0].ticketprice;
         herolist[i].poster=hero[0].poster;
         console.log("hello");
     }
 }
    //console.log(JSON.parse(hero[0].title));
    res.send(herolist);
   fs.writeFileSync(__dirname+"/data.json", JSON.stringify(herolist) );
});

app.post("/data/d",function(req, res){
 herolist= JSON.parse(fs.readFileSync(__dirname+"/data.json"));
 hero.push(JSON.parse(req.body));
 console.log(JSON.parse(req.body));
 delete herolist[(hero[0].sl)-1];
 res.send(herolist);
 herolist=herolist.filter(function(x){
      return x !== null ;
    });
 fs.writeFileSync(__dirname+"/data.json", JSON.stringify(herolist) );
})

app.listen(2020,"localhost", function(error){
    if(error){
        console.log(error +" : Happened")
    }else{
        console.log("server is now live on localhost:2020")
    }
})